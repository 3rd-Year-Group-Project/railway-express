import ControlOfficerLayout from '../../layout/ControlOfficerLayout';
import React from 'react';

export default function TrainLocation() {
  return (
    <ControlOfficerLayout>
      <h1>Live Train Location</h1>
    </ControlOfficerLayout>
  );
}
