import ControlOfficerLayout from '../../layout/ControlOfficerLayout';
import React from 'react';

export default function AddTurn() {
  return (
    <ControlOfficerLayout>
      <h1>Add Train Turn</h1>
    </ControlOfficerLayout>
  );
}
