import React from 'react';
import AdminLayout from '../../layout/AdminLayout';

export default function Statistics() {
  return (
    <AdminLayout>
      <h1 className="">Statistics</h1>
    </AdminLayout>
  );
}
